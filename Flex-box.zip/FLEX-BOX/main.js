	let toggleBtn = document.getElementById("toggleBtn");
toggleBtn.addEventListener("click", function(){
  let menubar = document.getElementById("menubar");
  menubar.classList.toggle("menubarToggle");
})