
$('document').ready(function (){
 
function loadAjaxData(){
 $.ajax({
        url:'data.json',
        type:'GET',
        dataType:'json',
        success: function (response){
          createChart(response);
      }
  });
}
loadAjaxData();

 function createChart(data){
   try {
     const chart = document.getElementById('myChart').getContext('2d');
     const myChart = new Chart(chart, {
        type:'bar',
        data:{
         labels:data.map(row => row.name),
           datasets:[{
            data:data.map(row => row.age),
            backgroundColor:['red','green']
           }]
         },
        options:{
           //Responsive
           responsive:true,
           maintainAspectRatio:false,
           aspectRatio:2,
           resizeDelay:0,
          // remove legend 
           plugins:{
            legend:{
              display: false,
              labels:{
               boxWidth:0
              }
            }
           },
    // Remove Grid lines and scale 
  scales:{
      x:{
       border: {
        display: false // Removes the x-axis border line
      },
       // ticks:{
       //     display:false
       //  },
       grid:{
          drawOnChartArea:false,
          drawTicks:false,
          drawBorder:false
       }
      },
      y:{
       beginAtZero: true,
       border: {
        display: false // Removes the x-axis border line
      },
       ticks:{
           display:false
        },
        grid:{
          drawOnChartArea:false,
          drawTicks:false,
          drawBorder:false,
       }
      }
   }
   // options end         
        }
     });
   // Change chart by buttons 
let bar = document.getElementById('bar');
let pie = document.getElementById('pie');

bar.addEventListener("click", changeBar);
pie.addEventListener("click", changePie);  
     
function changeBar(){
 const updateType = 'bar';
 myChart.config.type = updateType;
 myChart.update();
}

function changePie(){
 const updateType = 'pie';
 myChart.config.type = updateType;
 myChart.update();
}
     
 } catch (err) {
    console.error("Error fetching or creating chart:", err);
   }
 
}

});

