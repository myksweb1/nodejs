let toggleBtn = document.getElementById("toggleBtn");
toggleBtn.addEventListener("click", function(){
  let menu = document.getElementById("menu");
  if(menu.classList.contains("openMenu")){
    menu.classList.remove("openMenu");
    menu.classList.add("closeMenu");
    menu.innerHTML = `&#9747`;
  }else{
    menu.classList.add("openMenu");
    menu.classList.remove("closeMenu");
    menu.innerHTML = `&#9776`;
  }
 let sidebar = document.getElementById("sidebar");
 sidebar.classList.toggle("sidebarToggle");
})